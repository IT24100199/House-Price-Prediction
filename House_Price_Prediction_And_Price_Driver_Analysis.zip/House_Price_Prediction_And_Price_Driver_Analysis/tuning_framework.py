import os
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import KFold, GridSearchCV, RandomizedSearchCV
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

PROJECT_PATH = '/content/drive/MyDrive/IT3091_HousePrice_Project'
DATA_PATH    = f'{PROJECT_PATH}/data/processed'
RESULTS_PATH = f'{PROJECT_PATH}/results'
RANDOM_STATE = 42
N_FOLDS      = 5
SCORING      = 'neg_root_mean_squared_error'

def get_cv():
    # One shared splitter for ALL models: 5 folds, rows shuffled, same seed every time
    return KFold(n_splits=N_FOLDS, shuffle=True, random_state=RANDOM_STATE)


def tune_model(model, param_grid, X_train, y_train, search_type='grid', n_iter=20):
    # Find the best settings for a model using the shared cross-validation.
    #   model       : a scikit-learn model or Pipeline (not trained yet)
    #   param_grid  : dictionary of settings to try, e.g. {'n_estimators': [100, 300]}
    #   search_type : 'grid' (try everything) or 'random' (try n_iter random combinations)

    if search_type == 'grid':
        search = GridSearchCV(estimator=model, param_grid=param_grid,
                              cv=get_cv(), scoring=SCORING,
                              n_jobs=-1, refit=True, return_train_score=True)
    elif search_type == 'random':
        search = RandomizedSearchCV(estimator=model, param_distributions=param_grid,
                                    n_iter=n_iter, cv=get_cv(), scoring=SCORING,
                                    n_jobs=-1, refit=True, return_train_score=True,
                                    random_state=RANDOM_STATE)
    else:
        raise ValueError("search_type must be 'grid' or 'random'")

    search.fit(X_train, y_train)

    # best_score_ is negative RMSE, so I flip the sign to show a normal RMSE
    print('Best settings :', search.best_params_)
    print('Best CV RMSE  :', round(-search.best_score_, 4), '(log price scale, lower is better)')
    return search


def show_top_results(search, n=5):
    # Show the n best setting combinations, with train and validation scores side by side
    results = pd.DataFrame(search.cv_results_)
    table = pd.DataFrame({
        'rank':           results['rank_test_score'],
        'settings':       results['params'].astype(str),
        'train_RMSE':     -results['mean_train_score'],     # score on the folds the model learned from
        'validation_RMSE': -results['mean_test_score'],     # score on the held-out fold
        'validation_std': results['std_test_score']         # spread across the 5 folds
    })
    table['gap'] = table['validation_RMSE'] - table['train_RMSE']   # big gap = possible overfitting
    return table.sort_values('rank').head(n).round(4).reset_index(drop=True)


def evaluate_model(name, model, X_train, y_train, X_test, y_test, search=None):
    # Evaluate an ALREADY TRAINED model on train and test, in dollars

    # 1) Predict (still on the log scale)
    pred_train_log = model.predict(X_train)
    pred_test_log  = model.predict(X_test)

    # 2) Convert predictions AND true values back to dollars
    pred_train, actual_train = np.expm1(pred_train_log), np.expm1(y_train)
    pred_test,  actual_test  = np.expm1(pred_test_log),  np.expm1(y_test)

    # 3) Metrics in dollars
    rmse_train = np.sqrt(mean_squared_error(actual_train, pred_train))
    rmse_test  = np.sqrt(mean_squared_error(actual_test,  pred_test))
    mae_train  = mean_absolute_error(actual_train, pred_train)
    mae_test   = mean_absolute_error(actual_test,  pred_test)
    r2_train   = r2_score(actual_train, pred_train)
    r2_test    = r2_score(actual_test,  pred_test)

    # 4) RMSE on the log scale (the same scale used by cross-validation)
    rmse_test_log = np.sqrt(mean_squared_error(y_test, pred_test_log))

    # 5) Typical percentage error (median is not pulled up by a few big misses)
    median_pct_error = np.median(np.abs(actual_test - pred_test) / actual_test) * 100

    # 6) Overfitting check: how much worse is the test score than the train score?
    r2_gap = r2_train - r2_test
    rmse_ratio = rmse_test / rmse_train
    if r2_gap < 0.05:
        verdict = 'Low overfitting'
    elif r2_gap < 0.10:
        verdict = 'Moderate overfitting'
    else:
        verdict = 'High overfitting'

    result = {
        'model': name,
        'train_RMSE': round(rmse_train), 'test_RMSE': round(rmse_test),
        'train_MAE': round(mae_train),   'test_MAE': round(mae_test),
        'train_R2': round(r2_train, 4),  'test_R2': round(r2_test, 4),
        'test_RMSE_log': round(rmse_test_log, 4),
        'median_pct_error': round(median_pct_error, 1),
        'R2_gap': round(r2_gap, 4),
        'RMSE_ratio_test_vs_train': round(rmse_ratio, 2),
        'overfitting': verdict,
        'cv_RMSE_log': round(-search.best_score_, 4) if search is not None else None,
        'best_params': str(search.best_params_) if search is not None else None
    }

    print(f'--- {name} ---')
    print(f'RMSE : train ${rmse_train:,.0f} | test ${rmse_test:,.0f}')
    print(f'MAE  : train ${mae_train:,.0f} | test ${mae_test:,.0f}')
    print(f'R2   : train {r2_train:.3f} | test {r2_test:.3f}')
    print(f'Typical error on test: about {median_pct_error:.1f}% of the price')
    print('Overfitting check:', verdict, f'(R2 gap {r2_gap:.3f})')
    return result


def plot_residuals(name, model, X_test, y_test):
    # Residual plots in dollars (actual - predicted)
    predicted = np.expm1(model.predict(X_test))
    actual    = np.expm1(y_test)
    residuals = actual - predicted

    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5))

    # Left: residuals against predicted price
    axes[0].scatter(predicted, residuals, alpha=0.5, color='steelblue')
    axes[0].axhline(0, color='red', linestyle='--')
    axes[0].set_xlabel('Predicted price ($)')
    axes[0].set_ylabel('Residual = actual - predicted ($)')
    axes[0].set_title(f'{name}: residuals vs predicted')

    # Right: how the residuals are spread
    axes[1].hist(residuals, bins=30, color='seagreen', edgecolor='white')
    axes[1].axvline(0, color='red', linestyle='--')
    axes[1].set_xlabel('Residual ($)')
    axes[1].set_title(f'{name}: distribution of residuals')

    plt.tight_layout()
    plt.show()


def show_feature_importance(model, feature_names, top=15):
    # Plot the most important features for ANY model (trees use importances, linear models use coefficients)

    # If the model is a Pipeline, the real model is the last step
    final_model = model.steps[-1][1] if hasattr(model, 'steps') else model

    if hasattr(final_model, 'feature_importances_'):        # Random Forest, XGBoost
        values = pd.Series(final_model.feature_importances_, index=feature_names)
        title = 'Feature importance'
    elif hasattr(final_model, 'coef_'):                     # Linear, Ridge, Lasso
        values = pd.Series(np.abs(final_model.coef_), index=feature_names)
        title = 'Absolute coefficient (features must be scaled to compare fairly)'
    else:
        raise ValueError('This model has neither feature_importances_ nor coef_')

    top_values = values.sort_values().tail(top)
    top_values.plot.barh(figsize=(8, 6), color='darkorange')
    plt.title(title)
    plt.tight_layout()
    plt.show()
    return values.sort_values(ascending=False)


def save_result(result):
    # Save one model's result row as results/<model>.csv
    os.makedirs(RESULTS_PATH, exist_ok=True)
    file_name = result['model'].replace(' ', '_').replace('/', '_') + '.csv'
    pd.DataFrame([result]).to_csv(f'{RESULTS_PATH}/{file_name}', index=False)
    print('Saved to', f'{RESULTS_PATH}/{file_name}')


def load_all_results():
    # Join every saved model row into one comparison table (best test RMSE first).
    # Only files that look like a model result (they have 'model' and 'test_RMSE' columns) are used,
    # so other csv files in the results folder can never spoil the table.
    tables = []
    for file_name in os.listdir(RESULTS_PATH):
        if file_name.endswith('.csv'):
            table = pd.read_csv(f'{RESULTS_PATH}/{file_name}')
            if 'model' in table.columns and 'test_RMSE' in table.columns:
                tables.append(table)
    if len(tables) == 0:
        print('No model results saved yet')
        return None
    return pd.concat(tables, ignore_index=True).sort_values('test_RMSE').reset_index(drop=True)
